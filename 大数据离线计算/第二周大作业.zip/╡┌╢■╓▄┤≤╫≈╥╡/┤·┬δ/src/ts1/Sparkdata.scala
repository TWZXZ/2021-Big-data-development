package ts1
import java.lang
import java.util.Properties
import java.sql.{Connection, DriverManager, ResultSet, Statement}

import scala.math.Ordering

class Sparkdata {
  private var connection:Connection=null
  private var URL:String=null
  private var DCNAME:String=null
  private var USER:String=null
  private var PASSWORD:String=null
  private var sql:Statement=null
  private var resultSet:ResultSet=null

  def get(geturl:String ,dCName: String ,user: String, password: String):Unit= {

    URL = /*"jdbc:hive2://bigdata112.depts.bingosoft.net:22112/user10_db" */geturl
    DCNAME = /*"org.apache.hive.jdbc.HiveDriver"*/dCName
    USER = /*"user10"*/user
    PASSWORD=  /*"pass@bingo10"*/password

  }

  def getConnecton(): Connection = { //
    val url = URL
    val properties = new Properties()
    properties.setProperty("driverClassName",  DCNAME)
    properties.setProperty("user", USER)
    properties.setProperty("password", PASSWORD)

    connection = DriverManager.getConnection(url, properties)
    connection
  }

  def checkreturn(geturl:String ,dCName: String ,user: String, password: String): Boolean = {
    var checkbool = false

 /*   val url = geturl
    val properties = new Properties()
    properties.setProperty("driverClassName", dCName)
    properties.setProperty("user", user)
    properties.setProperty("password", password)
*/
    get(geturl,dCName,user,password)
    getConnecton()
    if ( !connection.isClosed()) checkbool = true

    checkbool
  }

  def DataGet(input:String): ResultSet ={

    sql = connection.createStatement()

    resultSet = sql.executeQuery(input)

    resultSet
  }

}
