package ts1;

import java.io.*;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;
import javafx.util.Callback;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import javafx.scene.control.TextArea;


public class MainController implements Initializable {
    private FXMLMain application;

    @FXML
    private TextArea GetInput;
    @FXML
    private TextArea Result;
    @FXML
    private ListView table;
    @FXML
    private TableView Out_Table;
    @FXML
    private TableView Detail_Table;
    private PrintStream ps;
    private ResultSet resultSet;
    private ObservableList<ObservableList> data;


    public void setApp(FXMLMain application) {
        this.application = application;
    }


    @FXML
    private void OUT_M(ActionEvent event) {
        application.useroutmain();
    }

    @FXML
    public void GETSQL(ActionEvent event) throws SQLException ,Exception{

        resultSet = application.ts1.DataGet(GetInput.getText());
       /* ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
        int num = resultSetMetaData.getColumnCount();
        List listOfRows = new List();
        while (resultSet.next()) {
            Map mapOfColValues = new HashMap(num);
            for (int i = 1; i <= num; i++) {
                mapOfColValues.put(resultSetMetaData.getColumnName(i), resultSet.getObject(i));
            }
            listOfRows.add(mapOfColValues.toString());
        }

        Result.setText(listOfRows.toString());
*/
        GetResult(resultSet);

    }



    @FXML
    public void SHOWTABLE(ActionEvent event) throws SQLException ,Exception{
        ObservableList<String> tablelist = application.getTables();
        System.out.println(tablelist);
        table.setItems(tablelist);
    }

    @FXML
    public void MOUSECLICK(MouseEvent mouseEvent)throws SQLException ,Exception{
        //System.out.println("clicked on " + table.getSelectionModel().getSelectedItem());
        ResultSet  resultSet1 = application.ts1.DataGet("select * from "+table.getSelectionModel().getSelectedItem());
        Showdetail(resultSet1);
    }


    @FXML
    public void Showdetail(ResultSet rs) throws SQLException,Exception {
        data = FXCollections.observableArrayList();
        Detail_Table.getItems().clear();
        for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
            //We are using non property style for making dynamic table
            final int j = i;
            TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i + 1));
            col.setCellValueFactory(new Callback<CellDataFeatures<ObservableList, String>, ObservableValue<String>>() {
                public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {
                    return new SimpleStringProperty(param.getValue().get(j).toString());
                }
            });

            Detail_Table.getColumns().addAll(col);
            System.out.println("Column [" + i + "] ");
        }

        while (rs.next()) {
            //Iterate Row
            ObservableList<String> row = FXCollections.observableArrayList();
            for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                //Iterate Column
                row.add(rs.getString(i));
            }
            System.out.println("Row [1] added " + row);
            data.add(row);
        }
        //FINALLY ADDED TO TableView
        Detail_Table.setItems(data);


    }

    @FXML
    public void GetResult(ResultSet re) throws SQLException ,Exception{
        data = FXCollections.observableArrayList();
        Out_Table.getItems().clear();
        for (int i = 0; i < re.getMetaData().getColumnCount(); i++) {
            //We are using non property style for making dynamic table
            final int f = i;
            TableColumn col = new TableColumn(re.getMetaData().getColumnName(i + 1));
            col.setCellValueFactory(new Callback<CellDataFeatures<ObservableList, String>, ObservableValue<String>>() {
                public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {
                    return new SimpleStringProperty(param.getValue().get(f).toString());
                }
            });

            Out_Table.getColumns().addAll(col);
            System.out.println("Column [" + i + "] ");
        }

        while (re.next()) {
            //Iterate Row
            ObservableList<String> row = FXCollections.observableArrayList();
            for (int i = 1; i <= re.getMetaData().getColumnCount(); i++) {
                //Iterate Column
                row.add(re.getString(i));
            }
            System.out.println("Row [1] added " + row);
            data.add(row);
        }
        //FINALLY ADDED TO TableView
        Out_Table.setItems(data);
    }






    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }






}
