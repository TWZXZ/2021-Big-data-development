package ts1;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController implements Initializable {
        @FXML private TextField URl;
        @FXML private TextField DCName;
        @FXML private TextField user;
        @FXML private PasswordField password;
        private FXMLMain application;

    public LoginController() {
    }


    public void setApp(FXMLMain application){
            this.application = application;
        }
        @FXML
        public void LOGIN_M(ActionEvent event) {

            application.userlogin(URl.getText(), DCName.getText() , user.getText() , password.getText());

        }

        @FXML
        private void CLEAR_M(ActionEvent event) {
            URl.setText(null);
            DCName.setText(null);
            user.setText(null);
            password.setText(null);
        }

        @Override
        public void initialize(URL url, ResourceBundle rb) {
            // TODO
        }


}
