package project;



import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;


import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.S3ObjectSummary;

import java.util.List;
public class Gets3pr {
     private final static String accessKey = "55CBCFFE0D417E43659B";
     private final static String secretKey = "WzE2NUE4OUE5QTAyQTg5QzcwNDdBMTI4RkI2OEUw";
     private final static String serviceEndpoint = "http://10.16.0.1:81";

     private final static String signingRegion = "";
     
     
	 public static List<S3ObjectSummary>  getS3(String bucket_name){
		 final BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey,secretKey);
			final ClientConfiguration ccfg = new ClientConfiguration().
					withUseExpectContinue(true);

			final EndpointConfiguration endpoint = new EndpointConfiguration(serviceEndpoint, signingRegion);

			final AmazonS3 s3 = AmazonS3ClientBuilder.standard()
	                .withCredentials(new AWSStaticCredentialsProvider(credentials))
	                .withClientConfiguration(ccfg)
	                .withEndpointConfiguration(endpoint)
	                .withPathStyleAccessEnabled(true)
	                .build();

	        ListObjectsV2Result result = s3.listObjectsV2(bucket_name);
	        List<S3ObjectSummary> objects = result.getObjectSummaries();
	        return objects;
		 
	 }
	//����
	 public static void main(String[] args) {

	        List<S3ObjectSummary> s3object= getS3("tangwei");
	        for (S3ObjectSummary os : s3object) {
	            System.out.println("* " + os.getKey());
	        }
	       

	    }
}
