package project;


import java.io.*;

import java.nio.file.*;
import java.nio.file.attribute.*;
import java.nio.channels.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;



import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.io.FileNotFoundException;
import java.io.File;
import java.util.*;
import java.io.FileInputStream;

import org.apache.commons.codec.digest.DigestUtils;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;

import project.GetLocalPr;
import project.Gets3pr;
import java.io.FileInputStream;
import com.amazonaws.AmazonClientException;

 
public class  watch{
    private final static String accessKey = "55CBCFFE0D417E43659B";
    private final static String secretKey = "WzE2NUE4OUE5QTAyQTg5QzcwNDdBMTI4RkI2OEUw";
    private final static String serviceEndpoint = "http://10.16.0.1:81";
    private final static String bucketName = "tangwei";
    private final static String signingRegion = "";
  
    public static void main(String[] args)  throws Exception{
    	
        final BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
        final ClientConfiguration ccfg = new ClientConfiguration().
                withUseExpectContinue(false);

        final EndpointConfiguration endpoint = new EndpointConfiguration(serviceEndpoint, signingRegion);

        final AmazonS3 s3 = AmazonS3ClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withClientConfiguration(ccfg)
                .withEndpointConfiguration(endpoint)
                .withPathStyleAccessEnabled(true)
                .build();
 
        String Path = ("C:\\Users\\TWZXZ\\OneDrive\\����\\ʵѵ\\ʵ��\\tangwei");//����
 
        // ��ȡ�ļ�ϵͳ��WatchService����

	    WatchService watchService = FileSystems.getDefault().newWatchService();
        Paths.get(Path).register(watchService 
                , StandardWatchEventKinds.ENTRY_CREATE
                , StandardWatchEventKinds.ENTRY_MODIFY
                , StandardWatchEventKinds.ENTRY_DELETE);
 
        File watchfile = new File(Path);
        LinkedList<File> fList = new LinkedList<File>();
        fList.addLast(watchfile);
        while (fList.size() > 0 ) {
            File f = fList.removeFirst();
            if(f.listFiles() == null)
                continue;
            for(File file2 : f.listFiles()){
                    if (file2.isDirectory()){//��һ��Ŀ¼
                    fList.addLast(file2);
                    //����ע����Ŀ¼
                    Paths.get(file2.getAbsolutePath()).register(watchService 
                            , StandardWatchEventKinds.ENTRY_CREATE
                            , StandardWatchEventKinds.ENTRY_MODIFY
                            , StandardWatchEventKinds.ENTRY_DELETE);
                }
            }
        }
        System.out.println("2");
        while(true)
        {
            // ��ȡ��һ���ļ��Ķ��¼�
            WatchKey key = watchService.take();
            for (WatchEvent<?> event : key.pollEvents()) 
            {System.out.println(event.kind());
        	final String keyName = Paths.get(Path+"\\"+event.context()).getFileName().toString();
            final File file = new File(Path+"\\"+event.context());
        	if(event.kind().equals(StandardWatchEventKinds.ENTRY_MODIFY)   || event.kind().equals( StandardWatchEventKinds.ENTRY_CREATE)) {
        	


                for (int i = 0; i < 2; i++) {
                    try {
                        s3.putObject(bucketName, keyName, file);
                        break;
                    } catch (AmazonServiceException e) {
                        if (e.getErrorCode().equalsIgnoreCase("NoSuchBucket")) {
                            s3.createBucket(bucketName);
                            continue;
                        }

                        System.err.println(e.toString());
                        System.exit(1);
                    } catch (AmazonClientException e) {
                        try {
                            // detect bucket whether exists
                            s3.getBucketAcl(bucketName);
                        } catch (AmazonServiceException ase) {
                            if (ase.getErrorCode().equalsIgnoreCase("NoSuchBucket")) {
                                s3.createBucket(bucketName);
                                continue;
                            }
                        } catch (Exception ignore) {
                        }

                        System.err.println(e.toString());
                        System.exit(1);
                    }
                }
        	}
        	else {//System.out.println("ɾ��bucket�ļ�");
        		try {
                    s3.deleteObject(bucketName, keyName);
                } catch (AmazonServiceException e) {
                    System.err.println(e.getErrorMessage());
                    System.exit(1);
                }
        	}
            }
            // ����WatchKey
            boolean valid = key.reset();
            // �������ʧ�ܣ��˳�����
            if (!valid) 
            {
                break;
            }
        }
       
        }
		
 }
        


