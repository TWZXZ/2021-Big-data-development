package project;

import java.io.File;
import java.util.*;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilterInputStream;
import java.io.IOException;

import org.apache.commons.codec.digest.DigestUtils;
public class GetLocalPr {
	  private final static String Path   = "C:\\Users\\TWZXZ\\OneDrive\\����\\ʵѵ\\ʵ��\\6-1";


	  public static List<String> getAllFile(String directoryPath,boolean isAddDirectory)throws Exception,IOException {
	    List<String> list = new ArrayList<String>();
	    File baseFile = new File(directoryPath);
	    if (baseFile.isFile() || !baseFile.exists()) {
	        return list;
	    }
	    File[] files = baseFile.listFiles();
	    for (File file : files) {
	        if (file.isDirectory()) {
	            if(isAddDirectory){
	                list.add(file.getAbsolutePath());
	            }
	            list.addAll(getAllFile(file.getAbsolutePath(),isAddDirectory));
	        } else {
	            list.add(file.getAbsolutePath());
	        }
	    }
	  
	    return list;
   	}
	//����
	  public static  void main(String[] args)throws Exception,IOException {
		
        final File file = new File("C:\\Users\\TWZXZ\\OneDrive\\����\\ʵѵ\\ʵ��\\6-1");
        final List<String> listdiretory = getAllFile("C:\\Users\\TWZXZ\\OneDrive\\����\\ʵѵ\\ʵ��\\6-1",true);
        System.out.println(listdiretory);
        System.out.println(listdiretory.size());
       
		System.out.println(Path.length());
		 FileInputStream fis = new FileInputStream(new File("C:\\Users\\TWZXZ\\OneDrive\\����\\ʵѵ\\ʵ��\\tangwei\\travel\\css\\style.css"));
	     String md5 = DigestUtils.md5Hex(fis);
	     fis.close();
	     System.out.println(md5);
		
		List<String>  relalist=new ArrayList();
	    for (String rela : listdiretory) {
			 relalist.add( rela.substring(Path.length()+1));
			 }
	    System.out.print(relalist);
	}
}
