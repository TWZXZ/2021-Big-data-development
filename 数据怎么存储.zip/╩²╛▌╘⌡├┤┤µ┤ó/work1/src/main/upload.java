package main;

import java.io.File;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.AbortMultipartUploadRequest;
import com.amazonaws.services.s3.model.CompleteMultipartUploadRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.PartETag;
import com.amazonaws.services.s3.model.UploadPartRequest;

import project.GetLocalPr;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map.Entry;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.amazonaws.AmazonClientException;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.AbortMultipartUploadRequest;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.CompleteMultipartUploadRequest;
import com.amazonaws.services.s3.model.CopyObjectRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.GetObjectTaggingRequest;
import com.amazonaws.services.s3.model.GetObjectTaggingResult;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadResult;
import com.amazonaws.services.s3.model.ListBucketsRequest;
import com.amazonaws.services.s3.model.ListMultipartUploadsRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ListPartsRequest;
import com.amazonaws.services.s3.model.MultipartUpload;
import com.amazonaws.services.s3.model.MultipartUploadListing;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.ObjectTagging;
import com.amazonaws.services.s3.model.PartETag;
import com.amazonaws.services.s3.model.PartListing;
import com.amazonaws.services.s3.model.PartSummary;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.UploadPartRequest;
import com.amazonaws.services.s3.model.Tag;
public class upload {


	private final static String bucketName = "tangwei";
    private final static String Path   = "C:\\Users\\TWZXZ\\OneDrive\\����\\ʵѵ\\ʵ��\\tangwei\\��ҵ����.zip";
    private final static String accessKey = "55CBCFFE0D417E43659B";
    private final static String secretKey = "WzE2NUE4OUE5QTAyQTg5QzcwNDdBMTI4RkI2OEUw";
    private final static String serviceEndpoint = "http://10.16.0.1:81";
	private static long PARTSIZE = 5 << 20;
	private final static String signingRegion = "";
	private final static String savepath="C:\\\\Users\\\\TWZXZ\\\\OneDrive\\\\����\\\\ʵѵ\\\\ʵ��\\\\tangwei";
	
	public static void main(String[] args) throws Exception,IOException{
		final BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey,secretKey);
		final ClientConfiguration ccfg = new ClientConfiguration().withUseExpectContinue(true);

		final EndpointConfiguration endpoint = new EndpointConfiguration(serviceEndpoint, signingRegion);

		final AmazonS3 s3 = AmazonS3ClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withClientConfiguration(ccfg)
                .withEndpointConfiguration(endpoint)
                .withPathStyleAccessEnabled(true)
                .build();
		
		String keyName = Paths.get(Path).getFileName().toString();
		
		List<String> listdiretory = GetLocalPr.getAllFile("C:\\Users\\TWZXZ\\OneDrive\\����\\ʵѵ\\ʵ��\\tangwei", true);
		
		reUploadFiles(s3,bucketName,savepath,listdiretory);
		File file=new File(Path);
		 uploadFile(s3, bucketName,keyName,file);
		
	}
	
public static void uploadFile(AmazonS3 s3, String bucketName, String keyName, File file) {
		
		System.out.println("upload: local lastModifiedTime"+ file.lastModified());
		// Create a list of UploadPartResponse objects. You get one of these
        // for each part upload.
		ArrayList<PartETag> partETags = new ArrayList<PartETag>();
		long contentLength = file.length();
		String uploadId = null;
		
		try {
			// Step 1: Initialize.
			InitiateMultipartUploadRequest initRequest = 
					new InitiateMultipartUploadRequest(bucketName, keyName);
			uploadId = s3.initiateMultipartUpload(initRequest).getUploadId();
			System.out.format("Created upload ID was %s\n", uploadId);

			// Step 2: Upload parts.
			long filePosition = 0;
			for (int i = 1; filePosition < contentLength; i++) {
				// Last part can be less than PARTSIZE B. Adjust part size.
				long partSize = Math.min(PARTSIZE, contentLength - filePosition);

				// Create request to upload a part.
				UploadPartRequest uploadRequest = new UploadPartRequest()
						.withBucketName(bucketName)
						.withKey(keyName)
						.withUploadId(uploadId)
						.withPartNumber(i)
						.withFileOffset(filePosition)
						.withFile(file)
						.withPartSize(partSize);
		

				// Upload part and add response to our list.
				System.out.format("Uploading part %d\n", i);
				PartETag ptag= s3.uploadPart(uploadRequest).getPartETag();
				System.out.println( ptag.getETag());
			
				partETags.add(ptag);
				

				filePosition += partSize;
			}

			// Step 3: Complete.
			System.out.println("Completing upload");
			CompleteMultipartUploadRequest compRequest = 
					new CompleteMultipartUploadRequest(bucketName, keyName, uploadId, partETags);

			s3.completeMultipartUpload(compRequest);
			
			//update the local file lastModified
			long modifiedTime = file.lastModified();
			System.out.println("local time: "+ new Date(modifiedTime));
			
			ObjectMetadata om = new ObjectMetadata();
			om.addUserMetadata("realModifiedTime",modifiedTime+"");
			CopyObjectRequest request = new CopyObjectRequest(bucketName,keyName,bucketName,keyName);
			request.setNewObjectMetadata(om);
			try {
				s3.copyObject(request);
			} catch (AmazonClientException e) {
				System.err.println(e.toString());
				System.exit(1);
			}
			ObjectMetadata om2 = s3.getObjectMetadata(bucketName, keyName);
			String res =  om2.getUserMetaDataOf("realModifiedTime");
			System.out.println("s3 time fianl : "+ new Date(Long.parseLong(res)));

			
		} catch (Exception e) {
			System.err.println(e.toString());
			if (uploadId != null && !uploadId.isEmpty()) {
				// Cancel when error occurred
				System.out.println("Aborting upload");
				s3.abortMultipartUpload(new AbortMultipartUploadRequest(bucketName, keyName, uploadId));
			}
			System.exit(1);
		}
		
	}
public static void reUploadFiles(AmazonS3 s3, String bucketName,String savePath, List<String> localFiles) {
	ListMultipartUploadsRequest allMultpartUploadsRequest = 
		     new ListMultipartUploadsRequest(bucketName);
	MultipartUploadListing multipartUploadListing = 
		     s3.listMultipartUploads(allMultpartUploadsRequest);
	List<MultipartUpload> lists =  multipartUploadListing.getMultipartUploads();
	
	for(MultipartUpload ml : lists) {
		String keyName = ml.getKey();
		String uploadID = ml.getUploadId();
		ListPartsRequest listPartsRequest = new ListPartsRequest(bucketName,keyName,uploadID);
		PartListing parts =  s3.listParts(listPartsRequest);
		parts.getKey();
		int partNumber = parts.getNextPartNumberMarker();
		List<PartSummary> psList =  parts.getParts();
		
		ArrayList<PartETag> partETags = new ArrayList<PartETag>();
		for(PartSummary ps : psList) {
//			System.out.print("part num: "+ps.getPartNumber());
//			System.out.println("    part size: "+ps.getSize());
//			System.out.println("    part time: "+ps.getLastModified());
//			System.out.println("part Etag: "+ps.getETag());
			partETags.add( new PartETag(ps.getPartNumber(),ps.getETag()));
		}
		reUploaderHelper(savePath,s3, bucketName, keyName,partETags,uploadID,partNumber);
	
		
		
	}

}

public static void reUploaderHelper(String savePath, AmazonS3 s3, String bucketName, String keyName,ArrayList<PartETag> partETags, String uploadId,int partNumber) {
	// Create a list of UploadPartResponse objects. You get one of these
    // for each part upload.
	File file = new File(savePath+"/"+keyName);
	if(!file.exists())
		return;
	long contentLength = file.length();
	try {

		// Step 2: Upload parts.
		long filePosition = partNumber * PARTSIZE ;
		for (int i = partNumber+1; filePosition < contentLength; i++) {
			// Last part can be less than PARTSIZE B. Adjust part size.
			long partSize = Math.min(PARTSIZE, contentLength - filePosition);

			// Create request to upload a part.
			UploadPartRequest uploadRequest = new UploadPartRequest()
					.withBucketName(bucketName)
					.withKey(keyName)
					.withUploadId(uploadId)
					.withPartNumber(i)
					.withFileOffset(filePosition)
					.withFile(file)
					.withPartSize(partSize);
	

			// Upload part and add response to our list.
			System.out.format("Uploading part %d\n", i);
			PartETag ptag= s3.uploadPart(uploadRequest).getPartETag();
			System.out.println( ptag.getETag());
		
			partETags.add(ptag);
			

			filePosition += partSize;
		}

		// Step 3: Complete.
		System.out.println("Completing upload");
		CompleteMultipartUploadRequest compRequest = 
				new CompleteMultipartUploadRequest(bucketName, keyName, uploadId, partETags);

		s3.completeMultipartUpload(compRequest);
		
		//update the local file lastModified
		long modifiedTime = file.lastModified();
		System.out.println("local time: "+ new Date(modifiedTime));
		
		ObjectMetadata om = new ObjectMetadata();
		om.addUserMetadata("realModifiedTime",modifiedTime+"");
		CopyObjectRequest request = new CopyObjectRequest(bucketName,keyName,bucketName,keyName);
		request.setNewObjectMetadata(om);
		try {
			s3.copyObject(request);
		} catch (AmazonClientException e) {
			System.err.println(e.toString());
			System.exit(1);
		}
		ObjectMetadata om2 = s3.getObjectMetadata(bucketName, keyName);
		String res =  om2.getUserMetaDataOf("realModifiedTime");
		System.out.println("s3 time fianl : "+ new Date(Long.parseLong(res)));

		
	} catch (Exception e) {
		System.err.println(e.toString());
		if (uploadId != null && !uploadId.isEmpty()) {
			// Cancel when error occurred
			System.out.println("Aborting upload");
			s3.abortMultipartUpload(new AbortMultipartUploadRequest(bucketName, keyName, uploadId));
		}
		System.exit(1);
	}
	
}

}

