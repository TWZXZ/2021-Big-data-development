package main;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.io.FileNotFoundException;
import java.util.Arrays;

import java.util.*;
import java.util.Map.Entry;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.amazonaws.AmazonClientException;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ListMultipartUploadsRequest;

import com.amazonaws.services.s3.model.ListPartsRequest;
import com.amazonaws.services.s3.model.MultipartUpload;
import com.amazonaws.services.s3.model.MultipartUploadListing;
import com.amazonaws.services.s3.model.PartETag;
import com.amazonaws.services.s3.model.PartListing;
import com.amazonaws.services.s3.model.PartSummary;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;


import org.apache.commons.codec.digest.DigestUtils;
import com.amazonaws.AmazonServiceException;
import project.GetLocalPr;
import project.Gets3pr;





public class Main {
    private final static String bucketName = "tangwei";
    private final static String Path   = "C:\\Users\\TWZXZ\\OneDrive\\����\\ʵѵ\\ʵ��\\tangwei";
    private final static String accessKey = "55CBCFFE0D417E43659B";
    private final static String secretKey = "WzE2NUE4OUE5QTAyQTg5QzcwNDdBMTI4RkI2OEUw";
    private final static String serviceEndpoint = "http://10.16.0.1:81";
    private static long PARTSIZE = 5 << 20;
    private final static String signingRegion = "";

 
    /**
     * @param args
     * @throws Exception
     * @throws IOException
     */
    public static void main(String[] args)throws Exception,IOException, FileNotFoundException,IndexOutOfBoundsException{
		final BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey,secretKey);
		final ClientConfiguration ccfg = new ClientConfiguration().
				withUseExpectContinue(true);

		final EndpointConfiguration endpoint = new EndpointConfiguration(serviceEndpoint, signingRegion);

		final AmazonS3 s3 = AmazonS3ClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withClientConfiguration(ccfg)
                .withEndpointConfiguration(endpoint)
                .withPathStyleAccessEnabled(true)
                .build();
/*��������ʱ���Ա����ļ���S3�е�bucket�ļ�ͬ��*/
       
		List<String> listdiretory = GetLocalPr.getAllFile(Path, true);
	    System.out.println(1);
	    List<String>  relalist=new ArrayList();//�����ļ����·��
	    for (String rela : listdiretory) {
			 relalist.add( rela.substring(Path.length()+1));
			 }
	    System.out.println("Get local file object");
	    
	    List<S3ObjectSummary> s3object= Gets3pr.getS3(bucketName);//��ȡS3bucket�ļ�����
        List<String> lists3diretory=new ArrayList();//s3�ļ�·��
        for (S3ObjectSummary os : s3object) {
            lists3diretory.add(os.getKey());
        }
        System.out.println("Get s3 file object");

       /*�ж�����δ��ɵķֿ��ϴ�/��������*/
        
        //����
        System.out.println(" check download");
		String recordsDir =Record.getDir();
		File localfile = new File(Path);
		String[] filelist=localfile.list();
		List<String> list = Arrays.asList(filelist);
		for(Entry<String, String> entry: Record.getAllKeyNameRecords().entrySet()) {
			String tempFileName = entry.getKey()+".S3DownloadTempData";
			if(list.contains(tempFileName)) {
				System.out.println("start redownload "+ entry.getKey());
				download.reDownloadHelper(Path,s3, bucketName, entry.getKey(),entry.getValue());
			}
			else {
				File file = new File(entry.getValue());
				file.delete();
			}
		}
		System.out.println("over");
		
		
		//�ϴ�
		ListMultipartUploadsRequest allMultpartUploadsRequest = new ListMultipartUploadsRequest(bucketName);
		MultipartUploadListing multipartUploadListing = s3.listMultipartUploads(allMultpartUploadsRequest);
		List<MultipartUpload> lists =  multipartUploadListing.getMultipartUploads();
		System.out.println(" check upload ");
		for(MultipartUpload ml : lists) {
			String keyName = ml.getKey();
			String uploadID = ml.getUploadId();
			ListPartsRequest listPartsRequest = new ListPartsRequest(bucketName,keyName,uploadID);
			PartListing parts =  s3.listParts(listPartsRequest);
			parts.getKey();
			int partNumber = parts.getNextPartNumberMarker();
			System.out.println("already upload part: "+partNumber);
			List<PartSummary> psList =  parts.getParts();
			
			ArrayList<PartETag> partETags = new ArrayList<PartETag>();
			
			for(PartSummary ps : psList) {
				partETags.add( new PartETag(ps.getPartNumber(),ps.getETag()));
			}
			upload.reUploaderHelper(Path,s3, bucketName, keyName,partETags,uploadID,partNumber);

			
			
		}
		System.out.println("over");
	
        //

		//�Ա�bucket�뱾�ص��ļ���������ͬ��
		for(String lists3 : lists3diretory) {
			String path= Path+"\\"+lists3;
			boolean exit=new File(path).exists();
			if(!exit){
				download.downloadFile(s3, bucketName, lists3, Path);
				
/*�ļ�sizeС��20MB			
		        S3ObjectInputStream s3is = null;
			    FileOutputStream fos = null;
			try {
				S3Object o = s3.getObject(bucketName, lists3);
				s3is = o.getObjectContent();
			    System.out.println(4);
				fos = new FileOutputStream(new File(path));
				System.out.println(5);
				byte[] read_buf = new byte[64 * 1024];
				int read_len = 0;
				while ((read_len = s3is.read(read_buf)) > 0) {
					fos.write(read_buf, 0, read_len);
				}
			} catch (AmazonServiceException e) {
				System.err.println(e.toString());
				System.exit(1);
			} catch (IOException e) {
				System.err.println(e.getMessage());
				System.exit(1);
			} finally {
				if (s3is != null) try { s3is.close(); } catch (IOException e) { }
				if (fos != null) try { fos.close(); } catch (IOException e) { }
			}*/
				
			}
				
		}
		
		
		/*��֤�ļ��汾*/
		
		//��ȡ�����ļ�md5ֵ

	    List<String> localdirelist = GetLocalPr.getAllFile(Path, true);
		ArrayList<String> md5=new ArrayList();
		for (String dire : localdirelist) {
		    File file = new File(dire);
	        if(file.isDirectory()){
	            md5.add("d41d8cd98f00b204e9800998ecf8427e");
	        }
	        if(file.isFile()){
	        	FileInputStream fis = new FileInputStream(new File(dire));
	        	md5.add(  DigestUtils.md5Hex(fis));
	        	 fis.close();
	        }
			    
			  
	   }
	
	    System.out.println(md5);
	    System.out.println(localdirelist);
	    
	  
	    
	    
	  //��ȡbucket���ļ�md5ֵ
	    ArrayList<String> ETag=new ArrayList();
	    for (S3ObjectSummary os : s3object) {
            ETag.add(os.getETag());
        }
	    System.out.println(ETag);
	    System.out.println(lists3diretory);

	    for (int i=0; i < ETag.size();i++) {
			if((md5.contains(ETag.get(i)))) {
			Date s3time =s3object.get(i).getLastModified();
			
			File file = new File(localdirelist.get(i));
			long localt= file.lastModified();
			Date localtime=new Date(localt);
			
			int t =s3time.compareTo(localtime);
			
			S3ObjectInputStream s3is = null;
		    FileOutputStream fos = null;
		    
			if(t>0){//�����ļ��������µ�
				download.downloadFile(s3, bucketName, s3object.get(i).getKey(), Path);}
				/*else {
					//s3���ǰ汾���µ�
					File fileup =new File(Path);
					upload.uploadFile(s3, bucketName, s3object.get(i).getKey(), fileup);
				}*/
				/*�ļ�sizeС��20MB
				
			try {
				S3Object o = s3.getObject(bucketName, s3object.get(i).getKey());
				s3is = o.getObjectContent();
				fos = new FileOutputStream(new File(localdirelist.get(i)));
				byte[] read_buf = new byte[64 * 1024];
				int read_len = 0;
				while ((read_len = s3is.read(read_buf)) > 0) {
					fos.write(read_buf, 0, read_len);
				}
			} catch (AmazonServiceException e) {
				System.err.println(e.toString());
				System.exit(1);
			} catch (IOException e) {
				System.err.println(e.getMessage());
				System.exit(1);
			} finally {
				if (s3is != null) try { s3is.close(); } catch (IOException e) { }
				if (fos != null) try { fos.close(); } catch (IOException e) { }
			}
			*/
			}
			
				
			
				
		}
	    
//���ӱ����ļ�����ͬ���ļ�
	    WatchService watchService = FileSystems.getDefault().newWatchService();
        Paths.get(Path).register(watchService 
                , StandardWatchEventKinds.ENTRY_CREATE
                , StandardWatchEventKinds.ENTRY_MODIFY
                , StandardWatchEventKinds.ENTRY_DELETE);
 
        File watchfile = new File(Path);
        LinkedList<File> fList = new LinkedList<File>();
        fList.addLast(watchfile);
        while (fList.size() > 0 ) {
            File f = fList.removeFirst();
            if(f.listFiles() == null)
                continue;
            for(File file2 : f.listFiles()){
                    if (file2.isDirectory()){//��һ��Ŀ¼
                    fList.addLast(file2);
                    //����ע����Ŀ¼
                    Paths.get(file2.getAbsolutePath()).register(watchService 
                            , StandardWatchEventKinds.ENTRY_CREATE
                            , StandardWatchEventKinds.ENTRY_MODIFY
                            , StandardWatchEventKinds.ENTRY_DELETE);
                }
            }
        }
        System.out.println("2");
        while(true)
        {
            // ��ȡ��һ���ļ��Ķ��¼�
            WatchKey key = watchService.take();
            for (WatchEvent<?> event : key.pollEvents()) 
            {System.out.println(event.context() +" --> " + event.kind());
        	final String keyName = Paths.get(Path+"\\"+event.context()).getFileName().toString();
            final File file = new File(Path+"\\"+event.context());
        	if(event.kind().equals(StandardWatchEventKinds.ENTRY_MODIFY)   || event.kind().equals( StandardWatchEventKinds.ENTRY_CREATE)) {
        	
        		
        		upload.uploadFile(s3, bucketName, keyName, file);
        		 /*�ļ�sizeС��20MB
                for (int i = 0; i < 2; i++) {
                    try {
                        s3.putObject(bucketName, keyName, file);
                        break;
                    } catch (AmazonServiceException e) {
                        if (e.getErrorCode().equalsIgnoreCase("NoSuchBucket")) {
                            s3.createBucket(bucketName);
                            continue;
                        }

                        System.err.println(e.toString());
                        System.exit(1);
                    } catch (AmazonClientException e) {
                        try {
                            // detect bucket whether exists
                            s3.getBucketAcl(bucketName);
                        } catch (AmazonServiceException ase) {
                            if (ase.getErrorCode().equalsIgnoreCase("NoSuchBucket")) {
                                s3.createBucket(bucketName);
                                continue;
                            }
                        } catch (Exception ignore) {
                        }

                        System.err.println(e.toString());
                        System.exit(1);
                    }
                }*/

        	}
        	else {//System.out.println("ɾ��bucket�ļ�");
        		try {
                    s3.deleteObject(bucketName, keyName);
                } catch (AmazonServiceException e) {
                    System.err.println(e.getErrorMessage());
                    System.exit(1);
                }
        	}
            }
            // ����WatchKey
            boolean valid = key.reset();
            // �������ʧ�ܣ��˳�����
            if (!valid) 
            {
                break;
            }
        }
       
	    
	    
	    
        
        
	    
	    
    }



}
 
