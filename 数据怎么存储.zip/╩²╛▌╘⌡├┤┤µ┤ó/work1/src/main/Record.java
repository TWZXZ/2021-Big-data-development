package main;

import java.io.File;
import java.io.FileFilter;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Record {
	
	public String fileName;
	public String storeName;
	public DocumentBuilder db;
	public Record(String fileName) throws ParserConfigurationException {
		DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
		db = df.newDocumentBuilder();
		this.fileName = fileName;
		this.storeName = System.currentTimeMillis()+"";
	}

	public static void main(String[] args) {
		try {
			Record record = new Record("test_file.txt");
			record.createDomXML();
			record.addPartInfo(1, "asdadaassd",(1024*5*1), (1024*5));
			//record.addPartInfo(2, "asdadaassd",(1024*5*2), (1024*5));
			
			
			
			NodeList list = record.getParts();
			
			
			int len = list.getLength();
			System.out.println("len:"+len);
			for(int i = 0; i < len; i++) {
				Node part = list.item(i);
				System.out.println( "partNum:"+part.getAttributes().getNamedItem("partNum").getNodeValue());
				System.out.println("partETag: "+part.getChildNodes().item(1).getTextContent());
				System.out.println("offSize: "+part.getChildNodes().item(3).getTextContent());
				
			}
			
			
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(Entry<String, String> entry: getAllKeyNameRecords().entrySet()) {
			System.out.println("name:"+ entry.getKey()+"  path:"+entry.getValue());
		}
		
	}
	public  void createDomXML() {
		try {
			Document document = db.newDocument();
			document.setXmlStandalone(true);
			Element record = document.createElement("S3DownloadRecord");
			
			Element downloadKeyName = document.createElement("keyName");
			downloadKeyName.setTextContent(fileName);
			Element realModified = document.createElement("realModifiedTime");
			realModified.setTextContent(System.currentTimeMillis()+"");
			record.appendChild(downloadKeyName);
			record.appendChild(realModified);
			document.appendChild(record);
			
			
			TransformerFactory tff = TransformerFactory.newInstance();
			Transformer tf = tff.newTransformer();
			tf.setOutputProperty(OutputKeys.INDENT, "yes");
			tf.transform(new DOMSource(document), new StreamResult(new File(getPath(storeName))));
			System.out.println("����S3DownloadRecord.xml�ɹ�");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("����S3DownloadRecord.xml"+"ʧ��");
		}
		System.out.println("xml test done");
	}
	
	public  NodeList getParts() {
		File f = new File(getPath(storeName));
		NodeList list = null;
		try {
			Document xmlDoc = db.parse(f);
			Element root = xmlDoc.getDocumentElement();
			list =  root.getElementsByTagName("Part");
		}catch(Exception e) {
			System.out.println("��ȡPartʧЧ");
			e.printStackTrace();
		}
		return list;
		
	}
	
	public static NodeList getParts(String path) {
		File f = new File(path);
		NodeList list = null;
		try {
			DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
			DocumentBuilder DB = df.newDocumentBuilder();
			Document xmlDoc = DB.parse(f);
			Element root = xmlDoc.getDocumentElement();
			list =  root.getElementsByTagName("Part");
		}catch(Exception e) {
			System.out.println("��ȡPartʧЧ");
			e.printStackTrace();
		}
		return list;
		
	}
	
	
	
	public  void addPartInfo( long partNum, String partETag, long offSize, long partSize) {
		addPartInfo(getPath(storeName) , partNum,  partETag,  offSize,  partSize) ;
	}
	
	public static void addPartInfo(String pathName ,long partNum, String partETag, long offSize, long partSize) {
		File f = new File(pathName);
		try {
			DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
			DocumentBuilder DB = df.newDocumentBuilder();
			Document xmlDoc = DB.parse(f);
			Element root = xmlDoc.getDocumentElement();
			
			Element node = xmlDoc.createElement("Part");
			node.setAttribute("partNum", partNum+"");
			
			Element PartETag = xmlDoc.createElement("partETag");
			PartETag.setTextContent(partETag);
			node.appendChild(PartETag);
			Element PartOffSize = xmlDoc.createElement("offSize");
			PartOffSize.setTextContent((offSize+""));
			node.appendChild(PartOffSize);

			root.appendChild(node);
						
			
			TransformerFactory tff = TransformerFactory.newInstance();
			Transformer tf = tff.newTransformer();
			tf.setOutputProperty(OutputKeys.INDENT, "yes");
			tf.transform(new DOMSource(xmlDoc), new StreamResult(new File(pathName)));
			
//			
		}catch(Exception e) {
			System.out.println("S3DownloadRecord.xml"+" ����partʧ��");
			
			e.printStackTrace();
		}
		System.out.println("S3DownloadRecord.xml"+" ����part�ɹ�");
		
		
	}
	
	
	
	private static String getPath(String storeName) {
		String path = "";
		path = Record.class.getProtectionDomain().getCodeSource().getLocation().getFile();
		return path+storeName+"."+ "S3DownloadRecord.xml";
	}
	public static String  getDir() {
		return Record.class.getProtectionDomain().getCodeSource().getLocation().getFile();
	}

	public static HashMap<String,String> getAllKeyNameRecords() {
		HashMap<String,String> map = new HashMap<>();
		File dir = new File(getDir());
		if(dir.exists()) {
			DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
			
			for(File file : dir.listFiles(new FileFilter() {
				@Override
				public boolean accept(File pathName) {
					return pathName.isFile() && pathName.getName().endsWith("S3DownloadRecord.xml");
				}
			})) {
				//String fileName = file.getName();
				//fileName = fileName.substring(0, fileName.length()- ".S3DownloadRecord.xml".length());
				try {
					DocumentBuilder DB = df.newDocumentBuilder();
					Document xmlDoc = DB.parse(file);
					Element root = xmlDoc.getDocumentElement();
					String keyName = root.getElementsByTagName("keyName").item(0).getTextContent();
					map.put(keyName, file.getAbsolutePath());
					
				}catch(Exception e) {
					System.out.println("��ȡʧЧ");
					file.delete();
					e.printStackTrace();
					
				}
				
			}
		}
		return map;
	}
	
	public void delete() {
		File file = new File(getPath(storeName));
		if(file.exists()) {
			file.delete();
			System.out.println("ɾ����ʱ���ؼ�¼�ɹ�");
		}
	}
	
	public static void delete(String path) {
		File file = new File(path);
		if(file.exists()) {
			file.delete();
			System.out.println("ɾ����ʱ���ؼ�¼�ɹ�");
		}
	}
	

}
