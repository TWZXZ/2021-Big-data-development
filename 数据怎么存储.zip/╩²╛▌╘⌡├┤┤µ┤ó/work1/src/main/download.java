package main;





import project.GetLocalPr;
import java.io.File;
import java.nio.file.Paths;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;


public class download {
	private final static String bucketName = "tangwei";
    private final static String filePath   = "C:\\Users\\TWZXZ\\OneDrive\\����\\ʵѵ\\ʵ��\\tangwei\\��ҵ����.zip";
    private final static String accessKey = "55CBCFFE0D417E43659B";
    private final static String secretKey = "WzE2NUE4OUE5QTAyQTg5QzcwNDdBMTI4RkI2OEUw";
    private final static String serviceEndpoint = "http://10.16.0.1:81";
	private static long PARTSIZE = 5 << 20;
	private final static String signingRegion = "";
	private final static String Path="C:\\Users\\TWZXZ\\OneDrive\\����\\ʵѵ\\ʵ��\\tangwei";
	
	public static void main(String[] args) throws Exception,IOException,FileNotFoundException{
		final BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey,secretKey);
		final ClientConfiguration ccfg = new ClientConfiguration().withUseExpectContinue(true);

		final EndpointConfiguration endpoint = new EndpointConfiguration(serviceEndpoint, signingRegion);

		final AmazonS3 s3 = AmazonS3ClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withClientConfiguration(ccfg)
                .withEndpointConfiguration(endpoint)
                .withPathStyleAccessEnabled(true)
                .build();
		
		String keyName = Paths.get(filePath).getFileName().toString();
		
		List<String> listdiretory = GetLocalPr.getAllFile(Path, true);
		System.out.println(listdiretory);
		
		
		reDownloadFile(s3,bucketName,Path,listdiretory);
		downloadFile(s3, bucketName,keyName,Path);
		
		
	}
	
	public static void downloadFile( AmazonS3 s3,String bucketName, String keyName, String Path) {
		final String filePath = Paths.get(Path, keyName).toString();
		File file = new File(filePath+".S3DownloadTempData");
		
		S3Object o = null;
		
		S3ObjectInputStream s3is = null;
		FileOutputStream fos = null;
		
		try {
			// Step 1: Initialize.
			ObjectMetadata oMetaData = s3.getObjectMetadata(bucketName, keyName);
			final long contentLength = oMetaData.getContentLength();
			final GetObjectRequest downloadRequest = 
					new GetObjectRequest(bucketName, keyName);

			fos = new FileOutputStream(file);
			
			Record records = new Record(keyName);
			records.createDomXML();
			
			// Step 2: Download parts.
			long filePosition = 0;
			for (int i = 1; filePosition < contentLength; i++) {
				// Last part can be less than partSi ze MB. Adjust part size.
				long partSize = Math.min(PARTSIZE, contentLength - filePosition);

				// Create request to download a part.
				downloadRequest.setRange(filePosition, filePosition + partSize);
				o = s3.getObject(downloadRequest);

				// download part and save to local file.
				System.out.format("Downloading part %d\n", i);
				s3is = o.getObjectContent();
				byte[] read_buf = new byte[64 * 1024];
				int read_len = 0;
				while ((read_len = s3is.read(read_buf)) > 0) {
					fos.write(read_buf, 0, read_len);
				}
				filePosition += partSize+1;
				
				records.addPartInfo(i, o.getObjectMetadata().getETag(), filePosition, partSize);
			}

			// Step 3: Complete.
			System.out.println("Completing download");
			System.out.format("save %s to %s\n", keyName, filePath);
			records.delete();
			File newFile = new File(filePath);
			fos.close();
			if(!file.renameTo(newFile)) {
				System.exit(-1);
			}
			
			//step 4: update the realModifiedTime
			
			ObjectMetadata om  = s3.getObjectMetadata(bucketName, keyName);
			
			long modifiedTime =  Long.parseLong(om.getUserMetaDataOf("realModifiedTime")) ;
			System.out.println("down realModifiedTime:"+modifiedTime);
			newFile.setLastModified(modifiedTime);
			
		} catch (Exception e) {
			System.err.println(e.toString());
			
			System.exit(1);
		} finally {
			if (s3is != null) try { s3is.close(); } catch (IOException e) { }
			if (fos != null) try { fos.close(); } catch (IOException e) { }
		}
	}
	public static void reDownloadFile(AmazonS3 s3, String bucketName, String savePath, List<String> localFiles) throws FileNotFoundException {
		

		String recordsDir =Record.getDir();
		for(Entry<String, String> entry: Record.getAllKeyNameRecords().entrySet()) {
			String tempFileName = entry.getKey()+".S3DownloadTempData";
			File localfile = new File(Path);
			String[] filelist=localfile.list();
			List<String> list = Arrays.asList(filelist);
			if(list.contains(tempFileName)) {
				reDownloadHelper(savePath,s3, bucketName, entry.getKey(),entry.getValue());
			}
			else {
				File file = new File(entry.getValue());
				file.delete();
			}
		}	
		
		
		
	}
    public static void reDownloadHelper(String savePath, AmazonS3 s3, String bucketName,String keyName, String recordPath) throws FileNotFoundException {
    	long maxOffSize = 0L;
    	long maxNum = 0L;
    	try {
			NodeList nodeList = Record.getParts(recordPath);
			
			for(int i = 0; i < nodeList.getLength(); i++) {
				Node part = nodeList.item(i);
				long partNum = Long.parseLong( part.getAttributes().getNamedItem("partNum").getNodeValue());
				System.out.println( "partNum:"+partNum);
				System.out.println("partETag: "+part.getChildNodes().item(1).getTextContent());
				long offsize = Long.parseLong(part.getChildNodes().item(3).getTextContent());
				System.out.println("offSize: "+offsize);
				if(offsize> maxOffSize ){
					maxOffSize = offsize;
					maxNum = partNum;
				}	
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    	RandomAccessFile file;
		try {
			file = new RandomAccessFile(savePath+"/"+keyName+".S3DownloadTempData","rw");
			file.seek(maxOffSize);
			S3Object o = null;
			
			S3ObjectInputStream s3is = null;			
			try {
				// Step 1: Initialize.
				ObjectMetadata oMetaData = s3.getObjectMetadata(bucketName, keyName);
				final long contentLength = oMetaData.getContentLength();
				final GetObjectRequest downloadRequest = 
						new GetObjectRequest(bucketName, keyName);
				
				// Step 2: Download parts.
				long filePosition = maxOffSize;
				for (long i = maxNum+1; filePosition < contentLength; i++) {
					// Last part can be less than partSi ze MB. Adjust part size.
					long partSize = Math.min(PARTSIZE, contentLength - filePosition);

					// Create request to download a part.
					downloadRequest.setRange(filePosition, filePosition + partSize);
					o = s3.getObject(downloadRequest);

					// download part and save to local file.
					System.out.format("Downloading part %d\n", i);
					s3is = o.getObjectContent();
					byte[] read_buf = new byte[64 * 1024];
					int read_len = 0;
					while ((read_len = s3is.read(read_buf)) > 0) {
						file.write(read_buf, 0, read_len);
					}
					filePosition += partSize+1;
					
					Record.addPartInfo(recordPath,i, o.getObjectMetadata().getETag(), filePosition, partSize);
				}

				// Step 3: Complete.
				System.out.println("Completing download");
				System.out.format("save %s to %s\n", keyName, savePath+"/"+keyName);
				Record.delete(recordPath);
				file.close();
				File newFile = new File(savePath+"/"+keyName);
				File oldFile = new File(savePath+"/"+keyName+".S3DownloadTempData");
				if(!oldFile.renameTo(newFile)) {
					System.out.println("nooooooo, line 782");
					System.exit(-1);
				}
				
				//step 4: update the realModifiedTime
				
				ObjectMetadata om  = s3.getObjectMetadata(bucketName, keyName);
				
				long modifiedTime =  Long.parseLong(om.getUserMetaDataOf("realModifiedTime")) ;
				System.out.println("down realModifiedTime:"+modifiedTime);
				newFile.setLastModified(modifiedTime);
				
			} catch (Exception e) {
				System.err.println(e.toString());
				
				System.exit(1);
			} finally {
				if (s3is != null) try { s3is.close(); } catch (IOException e) { }
				//if (fos != null) try { fos.close(); } catch (IOException e) { }
			}
			
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
	
}
